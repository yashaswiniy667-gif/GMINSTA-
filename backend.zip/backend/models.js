const mongoose = require('mongoose');

const UserSchema = new mongoose.Schema({
    username: { type: String, required: true, unique: true },
    bio: { type: String, default: "" },
    profilePic: { type: String, default: "https://randomuser.me/api/portraits/women/44.jpg" },
    followers: { type: Number, default: 0 },
    following: { type: Number, default: 0 },
    postsCount: { type: Number, default: 0 },
    fullname: { type: String, default: "" },
    password: { type: String },
    email: { type: String }
});

const PostSchema = new mongoose.Schema({
    username: { type: String, required: true },
    image: { type: String, required: true },
    likes: { type: [String], default: [] },
    comments: [{
        username: String,
        text: String,
        createdAt: { type: Date, default: Date.now }
    }],
    caption: { type: String, default: "" },
    createdAt: { type: Date, default: Date.now }
});

const MessageSchema = new mongoose.Schema({
    sender: { type: String, required: true },
    receiver: { type: String, required: true },
    text: { type: String, required: true },
    createdAt: { type: Date, default: Date.now }
});

const User = mongoose.model('User', UserSchema);
const Post = mongoose.model('Post', PostSchema);
const Message = mongoose.model('Message', MessageSchema);

module.exports = { User, Post, Message };
