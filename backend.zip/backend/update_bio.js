const mongoose = require('mongoose');
const User = require('./models/User');

mongoose.connect('mongodb://127.0.0.1:27017/gminsta')
    .then(async () => {
        const result = await User.updateMany(
            { username: { $in: ['yashaswini__bv', 'user1_final'] } },
            { $set: { bio: 'Every End Is A New Beginning...! \nJai shree Ram 🕉️' } }
        );
        console.log(`Updated bio for ${result.modifiedCount} users.`);
        process.exit();
    })
    .catch(err => {
        console.error(err);
        process.exit(1);
    });
