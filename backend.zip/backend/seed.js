const mongoose = require('mongoose');
const { User, Post, Reel, Message, Comment } = require('./models');

async function seedData() {
    await mongoose.connect('mongodb://127.0.0.1:27017/gminsta');
    
    // Clear existing data (Be careful! Only for demo)
    await User.deleteMany({});
    await Post.deleteMany({});
    await Reel.deleteMany({});

    // Create a demo user
    const user = new User({
        fullname: 'Demo User',
        username: 'demo_user',
        email: 'demo@example.com',
        password: 'password123' // Not hashed for simplicity in demo seeding
    });
    await user.save();

    // Create some posts
    const post1 = new Post({
        user: user._id,
        image: 'https://picsum.photos/seed/nature/600/600',
        caption: 'Beautiful morning in the hills! ⛰️ #nature #blessed'
    });
    const post2 = new Post({
        user: user._id,
        image: 'https://picsum.photos/seed/setup/600/600',
        caption: 'New coding setup complete! 💻🔥 #developer #setup'
    });
    await post1.save();
    await post2.save();

    // Create a second user for chat demo
    const user2 = new User({
        fullname: 'Priya Sharma',
        username: 'priya_sharma',
        email: 'priya@example.com',
        password: 'password123'
    });
    await user2.save();

    // Create some demo messages
    const msg1 = new Message({
        sender: user._id,
        recipient: user2._id,
        text: 'Hey Priya! Did you see the new posts?'
    });
    const msg2 = new Message({
        sender: user2._id,
        recipient: user._id,
        text: 'Yes! They look amazing. Loving the hills shot! ⛰️'
    });
    await msg1.save();
    await msg2.save();

    // Create a demo comment in the new collection
    const comment = new Comment({
        post: post1._id,
        user: user2._id,
        text: 'This is an amazing shot! 😍'
    });
    await comment.save();

    console.log('✅ Demo data (including separate Comments & Messages) seeded successfully!');
    process.exit();
}

seedData();
