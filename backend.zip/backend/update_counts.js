const mongoose = require('mongoose');
const User = require('./models/User');

mongoose.connect('mongodb://127.0.0.1:27017/gminsta')
    .then(async () => {
        const result = await User.updateMany(
            { username: { $in: ['yashaswini__bv', 'user1_final', 'yashaswini123'] } },
            { $set: { followers: 700, following: 258 } }
        );
        console.log(`Updated ${result.modifiedCount} users.`);
        process.exit();
    })
    .catch(err => {
        console.error(err);
        process.exit(1);
    });
