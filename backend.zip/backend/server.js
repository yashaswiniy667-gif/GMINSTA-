require('dotenv').config();
const express = require('express');
const path = require('path');
const mongoose = require('mongoose');
const cors = require('cors');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');

const User = require('./models/User');
const Post = require('./models/Post');
const Message = require('./models/Message');
const Story = require('./models/Story');

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '../')));

// Root route to serve index.html
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, '../index.html'));
});

// Database Connection
mongoose.connect(process.env.MONGO_URI)
    .then(() => {
        console.log('✅ Connected to MongoDB');
        seedSampleData();
    })
    .catch(err => console.error('❌ MongoDB connection error:', err));

// --- Seeding Logic ---
async function seedSampleData() {
    try {
        const userCount = await User.countDocuments();
        if (userCount === 0) {
            // Create a default user
            const hashedPassword = await bcrypt.hash('password123', 10);
            const admin = await User.create({
                name: 'GMI Admin',
                email: 'admin@gminsta.com',
                username: 'gminsta_official',
                password: hashedPassword,
                profilePic: 'https://api.dicebear.com/7.x/avataaars/svg?seed=admin',
                bio: 'Welcome to the official GMinsta! 🚀'
            });

            // Create some posts
            await Post.insertMany([
                {
                    user: admin._id,
                    image: 'https://images.unsplash.com/photo-1611162617213-7d7a39e9b1d7?auto=format&fit=crop&q=80&w=1000',
                    caption: 'Connecting the world, one post at a time! 🌍✨ #GMinsta #Social'
                },
                {
                    user: admin._id,
                    image: 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&q=80&w=1000',
                    caption: 'Coding the future. 💻🔥'
                }
            ]);
            console.log('🌱 Sample data seeded successfully');
        }
    } catch (err) {
        console.error('Seed error:', err);
    }
}

// --- Authentication Middleware ---
const authenticateToken = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (!token) return res.status(401).json({ message: 'Access denied. No token provided.' });

    jwt.verify(token, process.env.JWT_SECRET, (err, user) => {
        if (err) return res.status(403).json({ message: 'Invalid token.' });
        req.user = user;
        next();
    });
};

// --- Auth Routes ---
app.post('/api/auth/register', async (req, res) => {
    try {
        const { name, email, username, password } = req.body;
        const existingUser = await User.findOne({ $or: [{ email }, { username }] });
        if (existingUser) return res.status(400).json({ message: 'User already exists' });

        const user = new User({ name, email, username, password });
        await user.save();
        res.status(201).json({ message: 'User registered successfully' });
    } catch (err) { res.status(500).json({ message: err.message }); }
});

app.post('/api/auth/login', async (req, res) => {
    try {
        const { username, password } = req.body; // 'username' here can be username or email from the form
        const user = await User.findOne({ 
            $or: [{ username: username }, { email: username }] 
        });
        
        if (!user || !(await user.comparePassword(password))) {
            return res.status(400).json({ message: 'Invalid username/email or password' });
        }
        const token = jwt.sign({ id: user._id, username: user.username }, process.env.JWT_SECRET, { expiresIn: '1d' });
        res.json({ token, user: { id: user._id, username: user.username, name: user.name, profilePic: user.profilePic } });
    } catch (err) { res.status(500).json({ message: err.message }); }
});

// --- API Routes ---
app.get('/api/users/suggested', async (req, res) => {
    try {
        const users = await User.find().limit(10).select('username name profilePic');
        res.json(users);
    } catch (err) { res.status(500).json({ message: err.message }); }
});

app.get('/api/users/:username', async (req, res) => {
    const user = await User.findOne({ username: req.params.username }).select('-password');
    res.json(user);
});

app.get('/api/posts', async (req, res) => {
    const posts = await Post.find()
        .populate('user', 'username profilePic')
        .populate('comments.user', 'username')
        .sort({ createdAt: -1 });
    res.json(posts);
});

// --- Story Routes ---
app.get('/api/stories', async (req, res) => {
    try {
        const stories = await Story.find().populate('user', 'username profilePic').sort({ createdAt: -1 });
        res.json(stories);
    } catch (err) { res.status(500).json({ message: err.message }); }
});

app.post('/api/stories', authenticateToken, async (req, res) => {
    try {
        const story = new Story({ user: req.user.id, image: req.body.image });
        await story.save();
        res.status(201).json(story);
    } catch (err) { res.status(500).json({ message: err.message }); }
});

app.get('/api/posts/user/:username', async (req, res) => {
    const user = await User.findOne({ username: req.params.username });
    const posts = await Post.find({ user: user._id }).sort({ createdAt: -1 });
    res.json(posts);
});

app.post('/api/posts', authenticateToken, async (req, res) => {
    const post = new Post({ user: req.user.id, image: req.body.image, caption: req.body.caption });
    await post.save();
    res.status(201).json(post);
});

app.post('/api/posts/:id/like', authenticateToken, async (req, res) => {
    const post = await Post.findById(req.params.id);
    const index = post.likes.indexOf(req.user.id);
    if (index === -1) post.likes.push(req.user.id);
    else post.likes.splice(index, 1);
    await post.save();
    res.json(post);
});

app.post('/api/posts/:id/comment', authenticateToken, async (req, res) => {
    try {
        const post = await Post.findById(req.params.id);
        post.comments.push({ user: req.user.id, text: req.body.text });
        await post.save();
        const updatedPost = await Post.findById(req.params.id).populate('comments.user', 'username');
        res.json(updatedPost);
    } catch (err) { res.status(500).json({ message: err.message }); }
});

app.get('/api/reels', async (req, res) => {
    try {
        // In this mini-app, we treat any post with a vertical image as a reel
        // or just return all posts as reels for demonstration.
        const reels = await Post.find().populate('user', 'username profilePic').sort({ createdAt: -1 });
        res.json(reels);
    } catch (err) { res.status(500).json({ message: err.message }); }
});

app.get('/api/users/search/:query', async (req, res) => {
    const users = await User.find({ username: { $regex: req.params.query, $options: 'i' } }).limit(10).select('username name profilePic');
    res.json(users);
});

app.get('/api/messages/:otherUserId', authenticateToken, async (req, res) => {
    const messages = await Message.find({
        $or: [
            { sender: req.user.id, receiver: req.params.otherUserId },
            { sender: req.params.otherUserId, receiver: req.user.id }
        ]
    }).sort({ createdAt: 1 });
    res.json(messages);
});

app.post('/api/messages', authenticateToken, async (req, res) => {
    const message = new Message({ sender: req.user.id, receiver: req.body.receiverId, text: req.body.text });
    await message.save();
    res.status(201).json(message);
});

app.listen(PORT, () => console.log(`🚀 Server running on http://localhost:${PORT}`));
