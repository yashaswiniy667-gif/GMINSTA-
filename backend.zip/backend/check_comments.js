const mongoose = require('mongoose');
const Post = require('./models/Post');

mongoose.connect('mongodb://127.0.0.1:27017/gminsta')
    .then(async () => {
        const posts = await Post.find({ 'comments.0': { $exists: true } });
        console.log(`Found ${posts.length} posts with comments.`);
        posts.forEach(p => {
            console.log(`Post ID: ${p._id}, Comments: ${p.comments.length}`);
        });
        process.exit();
    })
    .catch(err => {
        console.error(err);
        process.exit(1);
    });
