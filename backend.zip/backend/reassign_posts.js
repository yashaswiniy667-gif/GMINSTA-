const mongoose = require('mongoose');
const User = require('./models/User');
const Post = require('./models/Post');

mongoose.connect('mongodb://127.0.0.1:27017/gminsta')
    .then(async () => {
        const users = await User.find({ username: { $in: ['priya_sharma', 'demo_user', 'gminsta_official', 'yashaswini__bv'] } });
        const userMap = {};
        users.forEach(u => userMap[u.username] = u._id);

        const allPosts = await Post.find({ user: userMap['yashaswini__bv'] });
        
        if (allPosts.length >= 6) {
            // Reassign 2 posts to priya_sharma
            await Post.findByIdAndUpdate(allPosts[0]._id, { user: userMap['priya_sharma'] });
            await Post.findByIdAndUpdate(allPosts[1]._id, { user: userMap['priya_sharma'] });
            
            // Reassign 2 posts to demo_user
            await Post.findByIdAndUpdate(allPosts[2]._id, { user: userMap['demo_user'] });
            await Post.findByIdAndUpdate(allPosts[3]._id, { user: userMap['demo_user'] });
            
            // Reassign 2 posts to gminsta_official
            await Post.findByIdAndUpdate(allPosts[4]._id, { user: userMap['gminsta_official'] });
            await Post.findByIdAndUpdate(allPosts[5]._id, { user: userMap['gminsta_official'] });
            
            console.log('Successfully reassigned 6 posts to different users.');
        } else {
            console.log('Not enough posts to reassign. Current count:', allPosts.length);
        }
        process.exit();
    })
    .catch(err => {
        console.error(err);
        process.exit(1);
    });
