const API_BASE_URL = 'http://localhost:5000/api';

/**
 * Centralized API request function
 * @param {string} endpoint - The API endpoint (e.g., '/auth/login')
 * @param {string} method - HTTP Method (GET, POST, etc.)
 * @param {object} body - Request body for POST/PUT
 * @returns {Promise<any>} - Response JSON
 */
async function apiRequest(endpoint, method = 'GET', body = null) {
    const token = localStorage.getItem('token');
    const headers = {
        'Content-Type': 'application/json'
    };

    if (token) {
        headers['Authorization'] = `Bearer ${token}`;
    }

    const options = {
        method,
        headers
    };

    if (body) {
        options.body = JSON.stringify(body);
    }

    try {
        const response = await fetch(`${API_BASE_URL}${endpoint}`, options);
        if (response.status === 401 || response.status === 403) {
            // Token expired or invalid
            localStorage.clear();
            if (!window.location.pathname.includes('index.html') && !window.location.pathname.includes('register.html')) {
                window.location.href = 'index.html';
            }
        }
        return await response.json();
    } catch (error) {
        console.error('API Error:', error);
        return { message: 'Network error or server down' };
    }
}

// Global UI utilities can go here (e.g., format dates, etc.)
function formatDate(dateString) {
    const options = { year: 'numeric', month: 'short', day: 'numeric' };
    return new Date(dateString).toLocaleDateString(undefined, options);
}
